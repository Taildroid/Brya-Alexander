export default function NotFound() {
    return (
        <div>
            <h1>Sorry Not found ":("</h1>
        </div>
    )
}