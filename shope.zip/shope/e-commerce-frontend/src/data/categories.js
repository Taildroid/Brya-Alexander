const categories = [
    {
        title: 'Speaker',
        imgUrl: './image/speaker.png',
        items: 4
    },
    {
        title: 'Desktop & Laptop',
        imgUrl: './image/laptop.png',
        items: 5
    },
    {
        title: 'DSLR Camera',
        imgUrl: './image/camera2.png',
        items: 6
    },
    {
        title: 'DSLR Camera',
        imgUrl: './image/camera2.png',
        items: 6
    },
    {
        title: 'DSLR Camera',
        imgUrl: './image/camera2.png',
        items: 6
    },
    {
        title: 'DSLR Camera',
        imgUrl: './image/camera2.png',
        items: 6
    },
]

export default categories;