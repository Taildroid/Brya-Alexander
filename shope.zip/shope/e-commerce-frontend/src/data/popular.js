const popProducts = [

    {
        id: 1,
        title: 'Cameras'
    },
    {
        id: 2,
        title: 'Laptops'
    },
    {
        id: 3,
        title: 'Tablets'
    },
    {
        id: 4,
        title: 'Mouse'
    }
]

export default popProducts

