const carouselData = [
    {
        name: 'Notebook',
        url: 'image/camera.png',
        style: 'sliderimg'
    },
    {
        name: 'Speaker',
        url: 'image/camera.png',
        style: 'sliderimg'
    },
    {
        name: 'Mobile',
        url: 'image/camera.png',
        style: 'sliderimg'
    },
    {
        name: 'Headset',
        url: 'image/camera.png',
        style: 'sliderimg'
    },
]

export default carouselData