react-project
Vercel дээрх Deploy хийсэн E-Commerce project харах линк. https://react-project-navy.vercel.app/

Сурсан зүйлс / things i learned: useState carousel react components react props routes, route map, filter (in details)

Дараа ашиглаж болох зүйлс / reusable compnents and ideas Wishlist product mapping in carousel


Future enhancements ideas:
Home page - Product Modal - showing description and details of the product. 
